/* This is part of the starter code! 
 * You need to complete this class yourself!*/
package util;

public class Grade {
    private int score;
    private String letterGrade;
    public int getScore() {
        return score;
    }
    public String getLetterGrade() {
        return letterGrade;
    }
}
